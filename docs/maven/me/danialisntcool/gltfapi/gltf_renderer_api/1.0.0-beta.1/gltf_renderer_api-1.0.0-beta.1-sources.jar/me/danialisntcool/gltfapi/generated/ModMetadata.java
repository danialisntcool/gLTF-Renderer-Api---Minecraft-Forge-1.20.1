package me.danialisntcool.gltfapi.generated;

public final class ModMetadata {
    public static final String MOD_ID = "gltf_renderer_api";
    public static final String MOD_NAME = "glTF Renderer API";
    public static final String MOD_VERSION = "1.0.0-beta.1";
    public static final String SUPPORT_URL = "https://discord.gg/JMstSCsJqr";
    public static final int MAX_RESOURCE_BYTES = 128 * 1024 * 1024;
    public static final int MAX_DECODED_BUFFER_BYTES = 256 * 1024 * 1024;

    private ModMetadata() {
    }
}
